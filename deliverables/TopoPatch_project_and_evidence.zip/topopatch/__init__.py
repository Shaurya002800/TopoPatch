"""TopoPatch research implementation."""
